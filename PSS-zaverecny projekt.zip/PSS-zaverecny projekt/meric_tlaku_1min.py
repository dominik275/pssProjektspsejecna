setUp = {
 'user' : 'pi',
 'password' : 'cokoliv',
 'host' : '192.168.8.102',
 'database' : 'tlak'
}
tableName = 'tlak1'

import threading
import mysql.connector
from datetime import datetime
from sense_hat import SenseHat


sense = SenseHat()
sense.get_pressure()

def writeLog():
 tlak = sense.get_pressure()
 sense.show_message(" %d mBar " % (tlak), scroll_speed=0.05)
 print " %d mBar " % (tlak)
 cnx = mysql.connector.connect(**setUp)
 print datetime.utcnow().isoformat() + 'Z'
 cnx.cursor().execute("INSERT INTO %s VALUES (null,\"%s\", \"%s\")" % (tableName, datetime.utcnow().isoformat() + 'Z', tlak))
 cnx.commit()
 cnx.close()
 global mainThread
 mainThread = threading.Timer(60, writeLog)
 mainThread.start()

writeLog();

print "Pro ukonceni scriptu, stisknete 1"

while(True) :
 if(raw_input() == "1"):
  print "Ukoncovani"
  mainThread.cancel()
  break
 writeLog()
