<?php
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Title</title>
	<script>
		setInterval(function(){
			window.location.reload();
		}, 1000)
	</script>
</head>
<body>
<?php

$pdo = new PDO($database_config['dsn'], $database_config['username'], $database_config['password']);
$result = $pdo->query('SELECT * FROM tlak1 ORDER BY id DESC LIMIT 1');
$tlaky = $result->fetchAll();

?>


<table>
	<tr>
		<th>Čas</th>
		<th>Tlak</th>
	</tr>
	<?php foreach($tlaky as $value){ ?>
		<tr>
			<td><?php echo $value['time'] ?></td>
			<td><?php echo $value['tlaky'] ?></td>
		</tr>
	<?php } ?>
</table>

</body>
</html>


